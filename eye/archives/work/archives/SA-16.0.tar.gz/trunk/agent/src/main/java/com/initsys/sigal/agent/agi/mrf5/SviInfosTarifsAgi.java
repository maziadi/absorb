package com.initsys.sigal.agent.agi.mrf5;

import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.asteriskjava.fastagi.AgiChannel;
import org.asteriskjava.fastagi.AgiException;
import org.asteriskjava.fastagi.AgiHangupException;
import org.asteriskjava.fastagi.AgiRequest;
import org.asteriskjava.live.HangupCause;

import com.initsys.sigal.numbers.PhoneNumberUtils;

import com.initsys.sigal.agent.SiAgentTemplate;

import com.initsys.sigal.agent.agi.IdentityException;
import com.initsys.sigal.agent.agi.LimitReachedException;
import com.initsys.sigal.agent.agi.IncomingAccountException;
import com.initsys.sigal.agent.agi.CallContext;
import com.initsys.sigal.agent.agi.SipHeaderIcidExtractor;

import com.initsys.sigal.vno.VnoConstants;

import com.initsys.sigal.protocol.Sigal.LidbQueryResponse;
import com.initsys.sigal.protocol.Sigal.ResponseStatus.ResponseStatusCode;

import static org.apache.commons.lang.StringUtils.defaultString;
import static org.apache.commons.lang.StringUtils.stripStart;
import static org.apache.commons.lang.StringUtils.stripEnd;
import static org.apache.commons.lang.StringUtils.isBlank;
import static org.apache.commons.lang.StringUtils.defaultString;

public class SviInfosTarifsAgi extends AbstractMrf5Agi {
  /** logger */
  static final Logger log = LoggerFactory.getLogger(SviInfosTarifsAgi.class);

  private String outgoingCallPrice, outgoingSmsPrice, receivedCallPrice, dataSessionPrice;

  private final String soundsPath = "/usr/share/asterisk/sounds/fr/digits/";

  public String getOutgoingCallPrice () {
    return outgoingCallPrice;
  }

  public String getOutgoingSmsPrice () {
    return outgoingSmsPrice;
  }

  public String getReceivedCallPrice () {
    return receivedCallPrice;
  }

  public String getDataSessionPrice () {
    return dataSessionPrice;
  }

  public void setOutgoingCallPrice (String outgoingCallPrice) {
    this.outgoingCallPrice = outgoingCallPrice;
  }

  public void setOutgoingSmsPrice (String outgoingSmsPrice) {
    this.outgoingSmsPrice = outgoingSmsPrice;
  }

  public void setReceivedCallPrice (String receivedCallPrice) {
    this.receivedCallPrice = receivedCallPrice;
  }

  public void setDataSessionPrice (String dataSessionPrice) {
    this.dataSessionPrice = dataSessionPrice;
  }

  protected String getIcid(AgiChannel channel) {
    try {
      return new SipHeaderIcidExtractor().getIcid(channel);
    } catch (IllegalStateException e) {
      // TODO: transitional block: no ICID was found we create a
      // transational one.
      String icid = "t-" + createIcid();
      log
        .warn("P-Charging-Vector (or ICID variable) was not found. Generating a transitional one: "
            + icid);
      return icid;
    }
  }

  private void sleep(long duration) {
    try {
      Thread.sleep(duration);
    } catch (InterruptedException e) {
      log.error("InterruptedException occured ");
    } catch (IllegalMonitorStateException e) {
      log.error("IllegalMonitorStateException occured ");
    }      
  }

  @Override
  public void handleCall(AgiRequest request, AgiChannel channel,
      CallContext callContext) throws AgiException, TimeoutException {

    LidbQueryResponse lidbResponse = getTemplate().queryLineInfoByNumber(
        callContext.getCalledNumber());

    if (ResponseStatusCode.NOT_FOUND == lidbResponse.getStatus().getCode()) {
      throw new IncomingAccountException("Unable to find LIDB account for '"
          + callContext.getCalledNumber() + "'");
    }

    if (!checkCounters(lidbResponse, false)) {
      // Unreachable block due to checkCounters implementation
      throw new LimitReachedException("Limit reached : a counter has reached its max value");
    }

    boolean loop = true;
    channel.answer();
    sleep(2000);
    sendInitialCdr(callContext);

    do {
      if (channel.streamFile("/var/lib/asterisk/sounds/svi_infos_tarifs_films/outgoing_call", "8") == '8') {
        continue;
      }
      if (channel.streamFile(soundsPath + getOutgoingCallPrice() , "8") == '8') {
        continue;
      }
      if (channel.streamFile("/var/lib/asterisk/sounds/svi_infos_tarifs_films/received_call", "8") == '8') {
        continue;
      }
      if (channel.streamFile(soundsPath + getReceivedCallPrice() , "8") == '8') {
        continue;
      }
      if (channel.streamFile("/var/lib/asterisk/sounds/svi_infos_tarifs_films/outgoing_sms", "8") == '8') {
        continue;
      }
      if (channel.streamFile(soundsPath + getOutgoingSmsPrice() , "8") == '8') {
        continue;
      }
      if (channel.streamFile("/var/lib/asterisk/sounds/svi_infos_tarifs_films/data_session", "8") == '8') {
        continue;
      }
      if (channel.streamFile(soundsPath + getDataSessionPrice() , "8") == '8') {
        continue;
      }
      if (channel.streamFile("/var/lib/asterisk/sounds/svi_infos_tarifs_films/end", "8") == '8') {
        continue;
      }
      if (channel.waitForDigit(3000) != '8') {
        loop = false;
      }
    } while (loop);
    callContext.setHangupCause("16");
  }

  @Override
  protected void prepareContext(AgiRequest request, AgiChannel channel,
      CallContext callContext) throws AgiException {
    callContext.setCallingNetwork(VnoConstants.INTERNAL_NETWORK);
    callContext.setCalledNetwork(VnoConstants.EXTERNAL_NETWORK);

    callContext.setCalledNumber(request.getExtension());
    callContext.setCallingAccountCode(getAccountCodeReq(request, channel));

    String callingNumber = channel.getFullVariable("${CALLERID(num)}");
    callContext.setCallingNumber(defaultString(stripStart(callingNumber,
            "+")));
    callContext.setCallingName(defaultString(request.getCallerIdName()));

    callContext.setBothCarrierCodes(getCarrierCodeReq(channel));
    callContext
      .setCalledAccountCode(getCalledAccountCodeFromSipDomainReq(channel));
  }
}
