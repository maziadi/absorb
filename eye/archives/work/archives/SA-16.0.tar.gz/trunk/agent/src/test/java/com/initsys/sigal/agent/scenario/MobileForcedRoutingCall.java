package com.initsys.sigal.agent.scenario;

public class MobileForcedRoutingCall extends AbstractScenario {
	public MobileForcedRoutingCall() {
		super();
	}

	public MobileForcedRoutingCall(ClassLoader cl) {
		super(cl);
	}
}
