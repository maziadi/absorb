package com.initsys.sigal.agent;

/**
 * Used as a cost less place holder when no statistics are required.
 */
public class DummyAgentStatistics implements AgentStatistics {

    public void addBillableDuration(Integer duration) {
        // do nothing
    }

    public void addDuration(Integer duration) {
        // do nothing

    }

    public void addTreatmentDuration(Integer duration) {
        // do nothing
    }

    public void addInviteLatency(Integer latency) {
        // do nothing
    }

    public void incrementBusyCauseCount() {
        // do nothing
    }

    public void incrementCallCount() {
        // do nothing
    }

    public void incrementCongestionCauseCount() {
        // do nothing
    }

    public void incrementEstablishedCallCount() {
        // do nothing
    }

    public void incrementExceptionCount() {
        // do nothing
    }

    public void incrementUnallocatedCauseCount() {
        // do nothing
    }
}
