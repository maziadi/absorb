package com.initsys.sigal.agent.scenario;


public class IsdnInboundCall extends AbstractScenario {
	public IsdnInboundCall() {
		super();
	}
	
	public IsdnInboundCall(ClassLoader cl) {
		super(cl);
	}
}
