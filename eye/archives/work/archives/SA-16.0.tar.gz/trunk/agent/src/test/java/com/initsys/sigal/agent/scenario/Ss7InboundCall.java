package com.initsys.sigal.agent.scenario;

public class Ss7InboundCall extends AbstractScenario {
	public Ss7InboundCall() {
		super();
	}

	public Ss7InboundCall(ClassLoader cl) {
		super(cl);
	}
}
