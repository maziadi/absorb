package com.initsys.sigal.agent.scenario;

public class Mrf5OutboundCall extends AbstractScenario {
	public Mrf5OutboundCall() {
		// empty
	}

	public Mrf5OutboundCall(ClassLoader cl) {
		super(cl);
	}
}
