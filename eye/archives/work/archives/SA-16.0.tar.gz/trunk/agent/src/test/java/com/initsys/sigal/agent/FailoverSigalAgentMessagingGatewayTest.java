package com.initsys.sigal.agent;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static junit.framework.Assert.fail;
import static org.easymock.EasyMock.createStrictMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.EasyMock.isNull;
import static org.easymock.EasyMock.isA;

import java.util.concurrent.TimeoutException;

import org.springframework.jms.core.MessageCreator;
import javax.jms.Queue;
import javax.jms.Topic;
import java.util.Date;
import org.springframework.jms.JmsException;
import org.springframework.jms.UncategorizedJmsException;

import org.easymock.EasyMock;
import org.easymock.IMocksControl;
import org.junit.Before;
import org.junit.Test;

import com.initsys.sigal.SigalTemplate;
import com.initsys.sigal.protocol.Sigal.Cdr;
import com.initsys.sigal.protocol.Sigal.EmdbQueryRequest;
import com.initsys.sigal.protocol.Sigal.EmdbQueryResponse;

public class FailoverSigalAgentMessagingGatewayTest {

    private SigalTemplate primaryTemplate;

    private SigalTemplate secondaryTemplate;

    private FailoverSigalAgentMessagingGateway gateway;

    private IMocksControl mockCtrl;
    public IMocksControl getMockCtrl() {
        return mockCtrl;
    }
    public void setMockCtrl(IMocksControl mockCtrl) {
        this.mockCtrl = mockCtrl;
    }

    @Before
    public void setUp() {
        setMockCtrl(EasyMock.createStrictControl());
        this.primaryTemplate = getMockCtrl().createMock(SigalTemplate.class);
        this.secondaryTemplate = getMockCtrl().createMock(SigalTemplate.class);
        this.gateway = new FailoverSigalAgentMessagingGateway();
        this.gateway.setPrimaryTemplate(primaryTemplate);
        this.gateway.setSecondaryTemplate(secondaryTemplate);
        /* this.gateway.setCdrQueueDestination(new ActiveMQQueue("sigal.cdr")); */
    }

    private void replay() {
        getMockCtrl().replay();
    }

    private void verify() {
        getMockCtrl().verify();
    }

    @Test
    public void testFailoverOnQuery() throws TimeoutException {
        this.gateway.setMaxFailureCount(2);
        expect(primaryTemplate.call(isA(EmdbQueryRequest.class))).andThrow(
                new TimeoutException("too long"));
        expect(primaryTemplate.call(isA(EmdbQueryRequest.class))).andThrow(
                new TimeoutException("too long"));
        replay();
        timeoutCall();
        assertFalse("not yet failed over", this.gateway.isFailedOver());
        assertEquals(1, this.gateway.getQueryFailureCount());
        timeoutCall();
        assertTrue("failed over", this.gateway.isFailedOver());
        assertEquals(0, this.gateway.getQueryFailureCount());
        verify();
    }

    @Test
    public void testFailoverOnCdr() throws TimeoutException {
        this.gateway.setMaxFailureCount(2);
        JmsException throwable = new UncategorizedJmsException("too long");

        // no Queue set with setCdrQueueDestination, testing null
        primaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        expectLastCall().andThrow(throwable);
        primaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        expectLastCall().andThrow(throwable);

        replay();
        timeoutCdr();
        assertFalse("not yet failed over", this.gateway.isFailedOver());
        assertEquals(1, this.gateway.getCdrFailureCount());
        timeoutCdr();
        assertTrue("failed over", this.gateway.isFailedOver());
        assertEquals(0, this.gateway.getCdrFailureCount());
        verify();
    }

    @Test
    public void testFailoverOnQueryAndCdr() throws TimeoutException {
        this.gateway.setMaxFailureCount(2);
        JmsException throwable = new UncategorizedJmsException("too long");

        // no Queue set with setCdrQueueDestination, testing null
        expect(primaryTemplate.call(isA(EmdbQueryRequest.class))).andThrow(
                new TimeoutException("too long"));
        primaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        expectLastCall().andThrow(throwable);
        expect(primaryTemplate.call(isA(EmdbQueryRequest.class))).andThrow(
                new TimeoutException("too long"));
        secondaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        expectLastCall().andThrow(throwable);

        replay();
        timeoutCall();
        assertFalse("not yet failed over", this.gateway.isFailedOver());
        assertEquals(1, this.gateway.getQueryFailureCount());
        timeoutCdr();
        assertFalse("not yet failed over", this.gateway.isFailedOver());
        assertEquals(1, this.gateway.getCdrFailureCount());
        timeoutCall();
        assertTrue("failed over", this.gateway.isFailedOver());
        assertEquals(0, this.gateway.getQueryFailureCount());
        timeoutCdr();
        assertTrue("failed over", this.gateway.isFailedOver());
        assertEquals(0, this.gateway.getCdrFailureCount());
        verify();
    }

    @Test
    public void testAlmostFailoverThenReFailoverOnQuery() throws TimeoutException {
        EmdbQueryResponse response = EmdbQueryResponse.newBuilder().setVersion(
                1).build();
        TimeoutException throwable = new TimeoutException("too long");

        this.gateway.setMaxFailureCount(3);

        expect(primaryTemplate.call(isA(EmdbQueryRequest.class))).andThrow(
                throwable);
        expect(primaryTemplate.call(isA(EmdbQueryRequest.class))).andReturn(
                response);
        expect(primaryTemplate.call(isA(EmdbQueryRequest.class))).andThrow(
                throwable).times(3);
        expect(secondaryTemplate.call(isA(EmdbQueryRequest.class))).andThrow(
                throwable);
        expect(secondaryTemplate.call(isA(EmdbQueryRequest.class))).andReturn(
                response);
        expect(secondaryTemplate.call(isA(EmdbQueryRequest.class))).andThrow(
                throwable).times(3);
        expect(primaryTemplate.call(isA(EmdbQueryRequest.class))).andThrow(
                throwable).times(3);

        replay();
        timeoutCall();
        assertEquals(1, this.gateway.getQueryFailureCount());
        assertFalse("not yet failed over", this.gateway.isFailedOver());
        this.gateway.queryEmergency("test", "test");
        assertEquals(0, this.gateway.getQueryFailureCount());
        assertFalse("not failed over", this.gateway.isFailedOver());
        timeoutCall();
        assertEquals(1, this.gateway.getQueryFailureCount());
        assertFalse("not failed over either", this.gateway.isFailedOver());

        timeoutCall();
        assertEquals(2, this.gateway.getQueryFailureCount());

        timeoutCall();
        assertEquals(0, this.gateway.getQueryFailureCount());
        assertTrue("failed over", this.gateway.isFailedOver());
        assertEquals(0, this.gateway.getQueryFailureCount());

        // Test non-blocked failureCounter
        this.gateway.setFailureDeltaTime(3000);
        this.gateway.setTime((new Date().getTime() / 1000) - 4);
        timeoutCall();
        assertEquals(1, this.gateway.getQueryFailureCount());
        assertTrue("not yet failed over", this.gateway.isFailedOver());
        this.gateway.queryEmergency("test", "test");
        assertEquals(0, this.gateway.getQueryFailureCount());
        assertTrue("not failed over", this.gateway.isFailedOver());
        timeoutCall();
        assertEquals(1, this.gateway.getQueryFailureCount());
        assertTrue("not refailed over", this.gateway.isFailedOver());

        timeoutCall();
        assertEquals(2, this.gateway.getQueryFailureCount());

        timeoutCall();
        assertFalse("refailed over", this.gateway.isFailedOver());
        assertEquals(0, this.gateway.getQueryFailureCount());

        // Test blocked failureCounter
        timeoutCall();
        assertEquals(0, this.gateway.getQueryFailureCount());
        timeoutCall();
        assertEquals(0, this.gateway.getQueryFailureCount());
        timeoutCall();
        assertEquals(0, this.gateway.getQueryFailureCount());
        assertFalse("refailed over", this.gateway.isFailedOver());

        verify();
    }

    @Test
    public void testAlmostFailoverThenReFailoverOnCdr() throws TimeoutException {
        JmsException throwable = new UncategorizedJmsException("too long");

        this.gateway.setMaxFailureCount(3);

        // no Queue set with setCdrQueueDestination, testing null
        primaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        expectLastCall().andThrow(throwable);
        primaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        primaryTemplate.send((Topic) isNull(), isA(MessageCreator.class));
        primaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        expectLastCall().andThrow(throwable).times(3);
        secondaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        expectLastCall().andThrow(throwable);
        secondaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        secondaryTemplate.send((Topic) isNull(), isA(MessageCreator.class));
        secondaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        expectLastCall().andThrow(throwable).times(3);
        primaryTemplate.send((Queue) isNull(), isA(MessageCreator.class));
        expectLastCall().andThrow(throwable).times(3);

        replay();
        timeoutCdr();
        assertEquals(1, this.gateway.getCdrFailureCount());
        assertFalse("not yet failed over", this.gateway.isFailedOver());
        this.gateway.sendCdrMessage(Cdr.newBuilder().setVersion(1).build());
        assertEquals(0, this.gateway.getCdrFailureCount());
        assertFalse("not failed over", this.gateway.isFailedOver());
        timeoutCdr();
        assertEquals(1, this.gateway.getCdrFailureCount());
        assertFalse("not failed over either", this.gateway.isFailedOver());

        timeoutCdr();
        assertEquals(2, this.gateway.getCdrFailureCount());

        timeoutCdr();
        assertEquals(0, this.gateway.getCdrFailureCount());
        assertTrue("failed over", this.gateway.isFailedOver());
        assertEquals(0, this.gateway.getCdrFailureCount());

        // Test non-blocked failureCounter
        this.gateway.setFailureDeltaTime(3000);
        this.gateway.setTime((new Date().getTime() / 1000) - 4);
        timeoutCdr();
        assertEquals(1, this.gateway.getCdrFailureCount());
        assertTrue("not yet failed over", this.gateway.isFailedOver());
        this.gateway.sendCdrMessage(Cdr.newBuilder().setVersion(1).build());
        assertEquals(0, this.gateway.getCdrFailureCount());
        assertTrue("not failed over", this.gateway.isFailedOver());
        timeoutCdr();
        assertEquals(1, this.gateway.getCdrFailureCount());
        assertTrue("not refailed over", this.gateway.isFailedOver());

        timeoutCdr();
        assertEquals(2, this.gateway.getCdrFailureCount());

        timeoutCdr();
        assertFalse("refailed over", this.gateway.isFailedOver());
        assertEquals(0, this.gateway.getCdrFailureCount());

        // Test blocked failureCounter
        timeoutCdr();
        assertEquals(0, this.gateway.getCdrFailureCount());
        timeoutCdr();
        assertEquals(0, this.gateway.getCdrFailureCount());
        timeoutCdr();
        assertEquals(0, this.gateway.getCdrFailureCount());
        assertFalse("refailed over", this.gateway.isFailedOver());

        verify();
    }
    private void timeoutCall() {
        try {
            this.gateway.queryEmergency("test", "test");
            fail("should have thrown a TimeoutException");
        } catch (TimeoutException e) {
            assertEquals("too long", e.getMessage());
        }
    }

    private void timeoutCdr() {
        try {
            this.gateway.sendCdrMessage(Cdr.newBuilder().setVersion(1).build());
            fail("should have thrown a JmsException");
        } catch (JmsException e) {
            assertEquals("too long", e.getMessage());
        }
    }

    @Test
    public void testStates() {
        assertFalse("initial state", this.gateway.isFailedOver());
        assertIsPrimary("initial state");
        this.gateway.failover();
        assertIsSecondary("failed over");
        this.gateway.failover();
        assertIsPrimary("failed over again");
    }

    private void assertIsPrimary(String label) {
        assertFalse(label, this.gateway.isFailedOver());
        assertEquals(label, this.primaryTemplate, this.gateway.getTemplate());
    }

    private void assertIsSecondary(String label) {
        assertTrue(label, this.gateway.isFailedOver());
        assertEquals(label, this.secondaryTemplate, this.gateway.getTemplate());
    }
}
