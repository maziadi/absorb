package com.initsys.sigal.agent.scenario;


public class Mrf5InboundCall extends AbstractScenario {
	public Mrf5InboundCall() {
		//empty
	}
	
	public Mrf5InboundCall(ClassLoader cl) {
		super(cl);
	}
}
