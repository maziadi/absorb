package com.initsys.sigal.service.as;

public class ExdbEntry {

    private Boolean locked;

    private String  carrierCode;

    private String  accountCode;

    private Integer maxInboundCalls;

    private Integer maxOutboundCalls;

    private Integer maxCalls;

    private String  inboundNumberingPlan;

    private String  outboundNumberingPlan;

    private String  subscriberNumber;

    private Boolean weirdIdentity;

    public String getAccountCode() {
        return accountCode;
    }

    public String getCarrierCode() {
        return carrierCode;
    }

    public String getInboundNumberingPlan() {
        return inboundNumberingPlan;
    }

    public Boolean getLocked() {
        return locked;
    }

    public Integer getMaxCalls() {
        return maxCalls;
    }

    public Integer getMaxInboundCalls() {
        return maxInboundCalls;
    }

    public Integer getMaxOutboundCalls() {
        return maxOutboundCalls;
    }

    public String getOutboundNumberingPlan() {
        return outboundNumberingPlan;
    }

    public String getSubscriberNumber() {
        return subscriberNumber;
    }

    public Boolean getWeirdIdentity() {
        return weirdIdentity;
    }

    public void setAccountCode(String accountCode) {
        this.accountCode = accountCode;
    }

    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    public void setInboundNumberingPlan(String inboundNumberingPlan) {
        this.inboundNumberingPlan = inboundNumberingPlan;
    }

    public void setLocked(Boolean locked) {
        this.locked = locked;
    }

    public void setMaxCalls(Integer maxCalls) {
        this.maxCalls = maxCalls;
    }

    public void setMaxInboundCalls(Integer maxInboundCalls) {
        this.maxInboundCalls = maxInboundCalls;
    }

    public void setMaxOutboundCalls(Integer maxOutboundCalls) {
        this.maxOutboundCalls = maxOutboundCalls;
    }

    public void setOutboundNumberingPlan(String outboundNumberingPlan) {
        this.outboundNumberingPlan = outboundNumberingPlan;
    }

    public void setSubscriberNumber(String subscriberNumber) {
        this.subscriberNumber = subscriberNumber;
    }

    public void setWeirdIdentity(Boolean weird) {
        this.weirdIdentity = weird;
    }
}
