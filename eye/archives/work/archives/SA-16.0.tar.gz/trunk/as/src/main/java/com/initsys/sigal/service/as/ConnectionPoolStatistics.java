package com.initsys.sigal.service.as;

public interface ConnectionPoolStatistics {

//  public ConnectionPoolStatistics(BasicDataSource dataSource);

  public int getNumActive();

  public int getNumIdle();

  public int getMaxActive();

  public void setMaxActive(int maxActive);

  public int getMaxIdle();

  public void setMaxIdle(int maxIdle);

  public int getMinIdle();

  public void setMinIdle(int minIdle);

  public long getMaxWait();

  public void setMaxWait(long maxWait);
}
