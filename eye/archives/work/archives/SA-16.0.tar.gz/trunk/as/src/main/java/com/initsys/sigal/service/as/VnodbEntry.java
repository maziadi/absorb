package com.initsys.sigal.service.as;

public class VnodbEntry {

    private String reference;
    
    private Integer maxCalls;

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Integer getMaxCalls() {
        return maxCalls;
    }

    public void setMaxCalls(Integer maxCalls) {
        this.maxCalls = maxCalls;
    }
}
