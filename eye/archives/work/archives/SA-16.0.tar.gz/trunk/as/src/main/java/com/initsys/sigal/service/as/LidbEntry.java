package com.initsys.sigal.service.as;

public class LidbEntry {

    private String number;

    private Boolean locked;

    private Boolean trunk;

    private String carrierCode;

    private Boolean presentation;

    private String inseeCode;

    private String redirectTo;

    private String accountCode;

    private String subscriberNumber;

    private Integer maxInboundCalls;

    private Integer maxOutboundCalls;

    private Integer maxCalls;

    private String inboundNumberingPlan;

    private String outboundNumberingPlan;

    private Boolean indication;

    private Boolean fax;
    
    private Integer voicemail;

    public Integer getVoicemail() {
        return voicemail;
    }

    public void setVoicemail(Integer voicemail) {
        this.voicemail = voicemail;
    }

    public Boolean getFax() {
        return fax;
    }

    public void setFax(Boolean fax) {
        this.fax = fax;
    }

    public Boolean getIndication() {
        return indication;
    }

    public void setIndication(Boolean indication) {
        this.indication = indication;
    }

    public Boolean getFixedCid() {
        return fixedCid;
    }

    public void setFixedCid(Boolean fixedCid) {
        this.fixedCid = fixedCid;
    }

    private Boolean fixedCid;

    public String getAccountCode() {
        return accountCode;
    }

    public String getCarrierCode() {
        return carrierCode;
    }

    public String getInboundNumberingPlan() {
        return inboundNumberingPlan;
    }

    public String getInseeCode() {
        return inseeCode;
    }

    public Boolean getLocked() {
        return locked;
    }

    public Integer getMaxCalls() {
        return maxCalls;
    }

    public Integer getMaxInboundCalls() {
        return maxInboundCalls;
    }

    public Integer getMaxOutboundCalls() {
        return maxOutboundCalls;
    }

    public String getNumber() {
        return number;
    }

    public String getOutboundNumberingPlan() {
        return outboundNumberingPlan;
    }

    public Boolean getPresentation() {
        return presentation;
    }

    public String getRedirectTo() {
        return redirectTo;
    }

    public String getSubscriberNumber() {
        return subscriberNumber;
    }

    public Boolean getTrunk() {
        return trunk;
    }

    public void setAccountCode(String accountCode) {
        this.accountCode = accountCode;
    }

    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    public void setInboundNumberingPlan(String inboundNumberingPlan) {
        this.inboundNumberingPlan = inboundNumberingPlan;
    }

    public void setInseeCode(String inseeCode) {
        this.inseeCode = inseeCode;
    }

    public void setLocked(Boolean locked) {
        this.locked = locked;
    }

    public void setMaxCalls(Integer maxCalls) {
        this.maxCalls = maxCalls;
    }

    public void setMaxInboundCalls(Integer maxInboundCalls) {
        this.maxInboundCalls = maxInboundCalls;
    }

    public void setMaxOutboundCalls(Integer maxOutboundCalls) {
        this.maxOutboundCalls = maxOutboundCalls;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setOutboundNumberingPlan(String outboundNumberingPlan) {
        this.outboundNumberingPlan = outboundNumberingPlan;
    }

    public void setPresentation(Boolean presentation) {
        this.presentation = presentation;
    }

    public void setRedirectTo(String redirectTo) {
        this.redirectTo = redirectTo;
    }

    public void setSubscriberNumber(String subscriberNumber) {
        this.subscriberNumber = subscriberNumber;
    }

    public void setTrunk(Boolean trunk) {
        this.trunk = trunk;
    }

}
