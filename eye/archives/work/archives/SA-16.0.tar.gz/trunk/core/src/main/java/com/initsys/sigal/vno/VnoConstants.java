package com.initsys.sigal.vno;

public class VnoConstants {
    public static final String EXTERNAL_NETWORK = "ext";

    public static final String INTERNAL_NETWORK = "int";

    public static final String EMERGENCY_CARRIER = "emergency";

    public static final String CAUSE_REDIRECT = "REDIRECT";

    public static final String REDIRECTED_FROM = "REDIRECTED_FROM";

    public static final String FAX_NUMBERING_PLAN_NUMBER = "5";

}
