package com.initsys.sigal.protocol;

public interface SigalProtocolConstants {

	public static final String PROTOCOL_ID = "SIGAL/1.0";
}
