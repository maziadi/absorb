#!/bin/sh

cd /root

cat > query.jmx <<EOF
get -b java.lang:type=Memory HeapMemoryUsage
get -b org.cipango:id=0,type=sessionmanager calls
get -b org.mortbay.thread:id=0,type=boundedthreadpool threads
EOF

while true
do 
  (echo open $(cat /var/run/jetty.pid); echo "run -b java.lang:type=Memory gc"; sleep 6; cat query.jmx; echo "close" ) | java -jar jmxterm-1.0-alpha-4-uber.jar -n -v silent
  sleep 300
done
