CREATE TABLE IF NOT EXISTS `<%= $vno_id %>_cafar` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `carrier` int(10) unsigned NOT NULL default '0',
  `domain` varchar(64) NOT NULL default '',
  `scan_prefix` varchar(64) NOT NULL default '',
  `host_name` varchar(128) NOT NULL default '',
  `reply_code` varchar(3) NOT NULL default '',
  `flags` int(11) unsigned NOT NULL default '0',
  `mask` int(11) unsigned NOT NULL default '0',
  `next_domain` varchar(64) NOT NULL default '',
  `description` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `<%= $vno_id %>_cr` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `carrier` int(10) unsigned NOT NULL default '0',
  `domain` varchar(64) NOT NULL default '',
  `scan_prefix` varchar(64) NOT NULL default '',
  `flags` int(11) unsigned NOT NULL default '0',
  `mask` int(11) unsigned NOT NULL default '0',
  `prob` float NOT NULL default '0',
  `strip` int(11) unsigned NOT NULL default '0',
  `rewrite_host` varchar(128) NOT NULL default '',
  `rewrite_prefix` varchar(64) NOT NULL default '',
  `rewrite_suffix` varchar(64) NOT NULL default '',
  `description` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `<%= $vno_id %>_dom` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `domain` varchar(64) NOT NULL default '',
  `last_modified` datetime NOT NULL default '1900-01-01 00:00:01',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `domain_idx` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `<%= $vno_id %>_loc` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(64) NOT NULL default '',
  `domain` varchar(64) default NULL,
  `contact` varchar(255) NOT NULL default '',
  `received` varchar(128) default NULL,
  `path` varchar(128) default NULL,
  `expires` datetime NOT NULL default '2020-05-28 21:32:15',
  `q` float(10,2) NOT NULL default '1.00',
  `callid` varchar(255) NOT NULL default 'Default-Call-ID',
  `cseq` int(11) NOT NULL default '13',
  `last_modified` datetime NOT NULL default '1900-01-01 00:00:01',
  `flags` int(11) NOT NULL default '0',
  `cflags` int(11) NOT NULL default '0',
  `user_agent` varchar(255) NOT NULL default '',
  `socket` varchar(64) default NULL,
  `methods` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `account_contact_idx` (`username`,`domain`,`contact`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `<%= $vno_id %>_rt` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `carrier` varchar(64) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `<%= $vno_id %>_sub` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(64) NOT NULL default '',
  `domain` varchar(64) NOT NULL default '',
  `password` varchar(25) NOT NULL default '',
  `email_address` varchar(64) NOT NULL default '',
  `ha1` varchar(64) NOT NULL default '',
  `ha1b` varchar(64) NOT NULL default '',
  `rpid` varchar(64) default NULL,
  `carrier` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `account_idx` (`username`,`domain`),
  KEY `username_idx` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `<%= $vno_id %>_tru` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `src_ip` varchar(50) NOT NULL,
  `proto` varchar(4) NOT NULL,
  `from_pattern` varchar(64) default NULL,
  `tag` varchar(32) default NULL,
  PRIMARY KEY  (`id`),
  KEY `peer_idx` (`src_ip`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

DELETE FROM `version` WHERE `table_name` LIKE '<%= $vno_id %>%';
INSERT IGNORE INTO `version` SELECT '<%= $vno_id %>_cafar', `table_version` FROM `version` WHERE `table_name`='carrierfailureroute';
INSERT IGNORE INTO `version` SELECT '<%= $vno_id %>_cr', `table_version` FROM `version` WHERE `table_name`='carrierroute';
INSERT IGNORE INTO `version` SELECT '<%= $vno_id %>_dom', `table_version` FROM `version` WHERE `table_name`='domain';
INSERT IGNORE INTO `version` SELECT '<%= $vno_id %>_loc', `table_version` FROM `version` WHERE `table_name`='location';
INSERT IGNORE INTO `version` SELECT '<%= $vno_id %>_rt', `table_version` FROM `version` WHERE `table_name`='route_tree';
INSERT IGNORE INTO `version` SELECT '<%= $vno_id %>_sub', `table_version` FROM `version` WHERE `table_name`='subscriber';
INSERT IGNORE INTO `version` SELECT '<%= $vno_id %>_tru', `table_version` FROM `version` WHERE `table_name`='trusted';
INSERT IGNORE INTO `<%= $vno_id %>_rt` VALUES (1,'inbound');
INSERT IGNORE INTO `<%= $vno_id %>_rt` VALUES (2,'outbound');
INSERT IGNORE INTO `<%= $vno_id %>_dom` VALUES (1,'<%= $opensips_service_addr %>',now());
