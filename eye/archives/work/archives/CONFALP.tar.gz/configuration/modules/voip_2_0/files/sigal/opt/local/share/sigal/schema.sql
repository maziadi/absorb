drop table if exists exchange_information;
drop table if exists number;
drop table if exists line_information;
drop table if exists emergency_translation;
drop table if exists emergency_holiday;

create table line_information (
	account_code varchar(15) primary key,
	subscriber_number varchar(15) not null unique,
	max_inbound_calls integer(5) not null default 1,
	max_outbound_calls integer(5) not null default 1,
	max_calls integer(5) not null default 1,
	inbound_numbering_plan varchar(31) not null,
	outbound_numbering_plan varchar(31) not null,
	locked char(1) not null,
	carrier_code varchar(32),
	trunk char(1) not null,
	fixed_cid char(1) not null,
	indication char(1) not null
) engine = InnoDB;

create table number (
	number varchar(31),
	redirect_to varchar(31),
	portability_prefix varchar(31),
	presentation char(1),
	insee_code varchar(5) not null,		
	subscriber_number varchar(31),
	primary key (number)
) engine = InnoDB;

create table exchange_information (
	account_code varchar(15),
	max_inbound_calls integer(5) not null default 1,
	max_outbound_calls integer(5) not null default 1,
	max_calls integer(5) not null default 1,
	inbound_numbering_plan varchar(31) not null,
	outbound_numbering_plan varchar(31) not null,
	locked char(1) not null,
	carrier_code varchar(32),
	primary key(account_code)
) engine = InnoDB;

create table emergency_translation (
	insee_code varchar(5) not null,
	number varchar(6) not null,
	day_of_week integer(1) null, 
	begin_hour time,
	end_hour time,
	idx integer(2) not null,
	translated_number varchar(15) not null
) engine = InnoDB;

create table emergency_holiday (
	day date not null,
	primary key (day)
) engine = InnoDB;


ALTER TABLE number 
	ADD CONSTRAINT `number_subscriber_number_c` 
	FOREIGN KEY `number_subscriber_number_fk` (subscriber_number)
    REFERENCES `line_information` (subscriber_number);

-- TODO: ajouter des indexes pour les recherchers
