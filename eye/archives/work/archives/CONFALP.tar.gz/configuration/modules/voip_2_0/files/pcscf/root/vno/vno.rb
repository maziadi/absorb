#!/usr/bin/env ruby

require 'erb'
require 'cmdparse2'

def my_template(infile, outfile, mode = 0640)
  templ = ERB::new(File.read(infile))
  txt = templ.result(binding)
  File::open(outfile, "w", mode) { |f| f.write txt }
  #txt
end

def vno_sql()
  print "Generating opensips' mysql config...\n"
  my_template("VNO.sql", "/root/vno/#{$vno_id}.sql")
  print "Importing opensips' mysql config...\n"
  `/usr/bin/mysql --defaults-file=/etc/mysql/debian.cnf opensips < /root/vno/#{$vno_id}.sql`
end

def vno_opensips()
  print "Generating opensips config...\n"
  my_template("VNO_opensips.cfg", "/etc/opensips/#{$vno_id}_opensips.cfg")
  print "Generating opensips default config...\n"
  my_template("VNO_opensips_default", "/etc/default/#{$vno_id}_opensips")
  print "Generating opensips init script...\n"
  my_template("VNO_opensips_init", "/etc/init.d/#{$vno_id}_opensips", 0755)
  print "Generating opensips' monit config...\n"
  $mail_domain_name = "#{`grep -q '^[[:space:]]*environment = development' /etc/puppet/puppet.conf && echo -n dev.`}admin.alphalink.fr"
  my_template("VNO_opensips_monit", "/etc/monitrc.d/#{$vno_id}_opensips")
  `monit reload`
  print " Adding system startup for /etc/init.d/#{$vno_id}_opensips...\n"
  `update-rc.d #{$vno_id}_opensips defaults 23`
end

def vno_mrfc4_sql()
  print "Generating opensips' mysql config for mrfc4 ...\n"
  my_template("MRFC4.sql", "/root/vno/#{$vno_id}_MRFC4.sql")
  print "Importing opensips' mysql config for mrfc4 ...\n"
  `/usr/bin/mysql --defaults-file=/etc/mysql/debian.cnf opensips < /root/vno/#{$vno_id}_MRFC4.sql`
end

cmd = CmdParse::CommandParser::new(true, true)
cmd.program_name = "vno.rb"
cmd.program_version = [0, 0, 1]

cmd.add_command(CmdParse::HelpCommand::new, true)
cmd.add_command(CmdParse::VersionCommand::new)

prov = CmdParse::Command::new('prov', false)
prov.short_desc = "Provision a VNO"
prov.description = "Provision opensips' base configuration for a VNO and launch it"
prov.description << """
  Example:
    ./vno.rb prov -i D201005050001 -t outbound -a 217.15.80.171
"""

prov.options = CmdParse::OptionParserWrapper::new do |opt|
  opt.on('-i', "--vno-id [VNO_ID]", "Specify vno_id") { |vno_id|
    $vno_id = vno_id
  }
  opt.on('-t', "--opensips-default-tree [TREE]", "Specify opensips default tree") { |default_tree|
    $opensips_default_tree = default_tree
  }
  opt.on('-a', "--opensips-service-addr [ADDR]", "Specify opensips service addr") { |service_addr|
    $opensips_service_addr = service_addr
  }
end

prov.set_execution_block do |args|
  if($vno_id.nil? || $opensips_default_tree.nil? || $opensips_service_addr.nil?)
    STDERR.print("Missing arguments\n")
    exit(1)
  end

  vno_sql
  vno_opensips
end

prov_mrfc4 = CmdParse::Command::new('prov_mrfc4', false)
prov_mrfc4.short_desc = "Provision a VNO mrfc4 rules"
prov_mrfc4.description = "Provision opensips' VNO mrfc4 rules"
prov_mrfc4.description << """
  Example:
    ./vno.rb prov_mrfc4 -i D201005050001
"""

prov_mrfc4.options = CmdParse::OptionParserWrapper::new do |opt|
  opt.on('-i', "--vno-id [VNO_ID]", "Specify vno_id") { |vno_id|
    $vno_id = vno_id
  }
end

prov_mrfc4.set_execution_block do |args|
  if($vno_id.nil?)
    STDERR.print("Missing arguments\n")
    exit(1)
  end

  vno_mrfc4_sql
end

cmd.add_command(prov)
cmd.add_command(prov_mrfc4)
cmd.parse
