#!/usr/bin/env ruby
#
# Script to build ZoneMinder video from jpeg image
#

require "sequel"
require "date"
require "fileutils"
require "find"
require "open4"
require "syslog"
require "log4r"
require 'log4r/outputter/syslogoutputter'
require "optparse"

include Log4r

ZM_PATH_FFMPEG="/usr/bin/ffmpeg"
ZM_EVENT_PATH="/var/cache/zoneminder/events"
ZM_VIDEO_PATH="/var/cache/zoneminder/videos"

logger = Logger.new 'create_zm_video'
logger.level = INFO
lo = Outputter.stdout
lo.level = WARNING
logger.outputters << lo
lo = SyslogOutputter.new("create_zm_video")
lo.level = INFO
logger.outputters << lo

if logger.level == DEBUG then
  FFMPEG_VERBOSE_LEVEL = 2
else
  FFMPEG_VERBOSE_LEVEL = -1
end

options = {}
# Age min des events en heure pour generer la video
options[:agemin]=12
# Age max des video en heure pour suppression
options[:agemaxvideo]=24
options[:simulate] = false


parser = OptionParser.new do |opts|
  opts.banner = "Usage: #{$0} [options]"
  opts.on("-s", "--simulate", "Do nothing, just print what we have to do") do |s|
    options[:simulate] = s
  end
  opts.on("--agemin H", Integer, "Event age in hours after we have to create video") do |a|
    options[:agemin] = a
  end
  opts.on("--agemaxvideo H", Integer, "Event age in hours after we have to delete video") do |b|
    options[:agemaxvideo] = b
  end
  opts.on_tail("-h", "--help", "Show this message") do
    puts opts
    exit
  end
end

begin
  parser.parse!
rescue OptionParser::ParseError => erreur
  puts erreur
  puts
  puts "Please see '--help' for valid options."
end

logger.info "Debut du script de creation des videos ZoneMinder - ageMin : #{options[:agemin]} heures - ageMaxVideo : #{options[:agemaxvideo]} heures - Simulation : #{options[:simulate]}"

# Lecture du fichier de conf zm pour parametre bdd
zmConf = File::new "/etc/zm/zm.conf","r"
zmOptions = zmConf.readlines
zmConf.close
hash = {}
zmOptions.each { |param|
  option = param.split('=')
  hash[option[0]] = option[1].chomp if option[1] != nil
}

# Calcul des dates limites
dateLimit = Time.now - options[:agemin] * 3600
dateLimitVideo = Time.now - options[:agemaxvideo] * 3600

# Suppression des vieilles video
Find.find ZM_VIDEO_PATH do |file|
  if (! File.directory?(file) and File.fnmatch('*_[0-9]*-[0-9]*avi',file)) then
    tropVieux = File.basename(file).split('-')[-1].split('.')[0].to_s <=> dateLimitVideo.strftime("%Y%m%d%H%M%S").to_s
    if tropVieux <= 0 then
      logger.info "Suppression de la video " + file
      if (! options[:simulate]) then
        begin
          File.unlink file
        rescue
          logger.err "Impossible de supprimer le fichier #{file} : " + $!
        end
      else
        logger.info "Simulate, no action"
      end
    end
  end
end

DB = Sequel.mysql hash["ZM_DB_NAME"], :host=>hash["ZM_DB_HOST"], :user=>hash["ZM_DB_USER"], :password=>hash["ZM_DB_PASS"]

# Recuperation du nombre de digit sur filename image
confD = DB[:Config].filter(:Name => "ZM_EVENT_IMAGE_DIGITS").first[:Value]

# Recuperation des events plus vieux que ageMin
listEvents = DB[:Events].filter(:EndTime < dateLimit.strftime("%Y-%m-%d %H:%M:%S")).join(DB[:Monitors].select(:Id.as(:IdMonitor),:Name), :IdMonitor=>:MonitorId)

# Creation des videos
listEvents.each { |event|
  # parametre de la video
  fileVideoEvent = ZM_VIDEO_PATH + "/#{event[:Name]}/#{event[:Name]}_#{event[:StartTime].strftime("%Y%m%d%H%M%S")}-#{event[:EndTime].strftime("%Y%m%d%H%M%S")}.avi"
  frameRate = event[:Frames] / event[:Length]
  videoSize = event[:Width].to_s + "x" + event[:Height].to_s
  bitrate = (200000 * event[:Width] * event[:Height] / (640*480.0)).to_i
  command = ZM_PATH_FFMPEG + " -v #{FFMPEG_VERBOSE_LEVEL} -y -b #{bitrate} -r " + "%0.2f" % frameRate + " -i #{ZM_EVENT_PATH}/#{event[:Name]}/#{event[:Id]}/%0" + confD + "d-capture.jpg -s " + videoSize + " -r 25 " + fileVideoEvent
  # Verification de la non existence de la video et creation
  if (! File.exist?(fileVideoEvent)) then
    logger.info "Creation de la video #{fileVideoEvent} ... "
    logger.debug command
    if (! options[:simulate]) then
      FileUtils.mkdir_p ZM_VIDEO_PATH + "/#{event[:Name]}"
      pid, stdin, stdout, stderr = Open4::popen4("#{command}")
      ignored, status = Process::waitpid2 pid
      if status.exitstatus != 0 then
        logger.err "FFMPEG ERROR"
        stderr.readlines.each { |line| logger.err line }
        stdout.readlines.each { |line| logger.err line }
        logger.err "Arret du script"
        exit 1
      end
      #stdin, stdout, stderr = Open3::popen3("#{command}")
      stderr.readlines.each { |line| logger.debug line }
      stdout.readlines.each { |line| logger.debug line }
    else
      logger.info "Simulate, no action"
    end
  end
}

logger.info "Fin du script de creation des videos ZoneMinder"
