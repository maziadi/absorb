PRI_DIR = "dist/services/dns/primary/var/bind/pri"
PRI_ETC_DIR = "dist/services/dns/primary/etc/bind"
SEC_ETC_DIR = "dist/services/dns/secondary/etc/bind"

