#!/usr/bin/env ruby

class String
  # colorization
  def colorize(color_code)
    "\e[#{color_code}m#{self}\e[0m"
  end

  def red
    colorize(31)
  end

  def green
    colorize(32)
  end

  def yellow
    colorize(33)
  end

  def blue
    colorize(34)
  end
end

#@hosts = ['si-preprod-erp-tech-1', 'erp-gestion-preprod-1']
Thread.abort_on_exception = true
STDOUT.sync = true
@dry_run = ARGV.delete('--test') ? true : false
@threads = []
@threads_output_buffer = []
threads_output_buffer_reader = Thread.new do
  log_fio = File.open(Time.now.strftime("/tmp/raz_preprod-%Y.%m.%d-%H:%M:%S"),'w')
  begin
    loop do
      while line = @threads_output_buffer.shift
        puts line
        log_fio.puts line
      end
      sleep 0.5
    end
  ensure
    while line = @threads_output_buffer.shift
      puts line
      log_fio.puts line
    end
    log_fio.close
  end
end

# Absolument aucune vérif, donc attention à l'échappement des guillemets et autres !

def ssh(host,command,ssh_options=nil)
  local_command = "ssh -q -oUserKnownHostsFile=/dev/null -oStrictHostKeyChecking=no -oBatchMode=yes #{ssh_options} #{host} \"#{command}\" 2>&1"
  @threads_output_buffer.push local_command.yellow
  unless @dry_run
    IO.popen(local_command) do |io|
      io.each do |line|
        @threads_output_buffer.push " #{host} => #{line}"
      end
    end unless @dry_run
    status = $?
    if not status.success?
      message = " #{host} !!!!!!!!!!!!!!!!!!!!!! ERROR : #{status.exitstatus} !!!!!!!!!!!!!!!!!!!!!!".red
      STDERR.puts message
      @threads_output_buffer.push message
    end
    status.success?
  else
    true
  end
end

# Le booléen indique l'état normal du service, démarré ou pas
Services = {
  'clockwork-preprod-1' => {
    'eligibilityd' => true,
    'eligibility-bgd' => true,
  },
  'egp-preprodclient-1' => {
    'pouss-mouss' => true,
    'messenger' => true,
    'delayed_job_pouss-mouss' => true,
  },
  'erp-gestion-preprod-1' => {
    'messenger' => true,
    'ticket_modif_group' => true,
    'batch_group' => true,
    'order_group' => true,
    'order_event_group' => true,
    'erp' => true,
  },
  'si-drive-preprod-1' => {
    'messenger' => true,
    'drive' => true,
    'delayed_job_drive' => true,
  },
  'si-factu-preprod-1' => {
    'killbill' => true,
  },
  'si-preprod-erp-tech-1' => {
    'obao' => true,
    'delayed_job' => true,
    'anderson' => true,
  },
  'si-proxy-preprod-1' => {
    'uixiv' => true,
  },
  'taxerp-preprod-1' => {
    'taxman' => true,
    'messenger' => true,
    'jobs' => true,
    'voip' => true,
    'mediation' => true,
    'outback' => true,
    'cashbot' => true,
    'mobile' => true,
  },
  'taxerp-preprod-2' => {
    'mediation' => false,
    'voip' => false,
  },
  'sso-preprod-1' => {
    'hector' => true,
    'cas' => true,
  },
}

# File ActiveMQ à vider
AMQueues= {
  'taxerp-preprod-1' => [
    'cdr0',
    'cdr1',
    'cdrs',
    'mobile',
    'voip_tickets',
  ],
  'taxerp-preprod-2' => [
    'cdr0',
    'cdr1',
    'cdrs',
    'mobile',
    'voip_tickets',
  ],
  'si-drive-preprod-1' => [
    'drive',
    'anderson',
    'pouss_mouss',
    'taxman',
  ],
  'si-proxy-preprod-1' => [
    'provisioning',
    'clockwork_upload',
    'clockwork_download',
    'BatchEligibility',
    'ObjectModification',
    'supervision',
    'eligibility_main',
    'sfr_prov',
    'hermes',
  ],
}

ExportsHost = 'archives-2'
ExportsDirectory = '/data/si-dump'
ExportsFiles = {
  'erp-gestion-preprod-1' => {
    :destination_directory => '/tmp',
    :files => [ 'anderson.dump.bz2', 'erp.dump.bz2' ],
  },
  'si-preprod-erp-tech-1' => {
    :destination_directory => '/tmp',
    :files => [ 'anderson.tar.bz2' ],
  },
  'taxerp-preprod-1' => {
    :destination_directory => '/data/import',
    :files => %w{taxman taxman_gauges taxman_mobile taxman_reports taxman_tickets}.map {|db_name| "#{db_name}.tar.bz2" },
  },
  'si-factu-preprod-1' => {
    :destination_directory => '/tmp',
    :files => [ 'killbill.dump.bz2' ],
  },
  'si-proxy-preprod-1' => {
    :destination_directory => '/tmp',
    :files => [ 'drive.tar.bz2', 'poussmouss.tar.bz2' ],
  },
}

ImportActions = {
  'erp-gestion-preprod-1' => [
    # anderson
    'bunzip2 -f /tmp/anderson.dump.bz2',
    'mysql --defaults-file=/etc/mysql/debian.cnf anderson_preproduction < /tmp/anderson.dump',
    'rm /tmp/anderson.dump',
    # erp
    'bunzip2 -f /tmp/erp.dump.bz2',
    'mysql --defaults-file=/etc/mysql/debian.cnf erp_preproduction < /tmp/erp.dump',
    'rm /tmp/erp.dump',
  ],
  'si-preprod-erp-tech-1' => [
    # anderson
    '[ -e /tmp/data ] && rm -rf /tmp/data || true',
    'rm -rf /data/anderson/neo4j/*',
    'tar -C /tmp -xjf /tmp/anderson.tar.bz2',
    'su - anderson -c \"JRUBY_OPTS=\'-J-XX:PermSize=256M -J-XX:MaxPermSize=512M -J-Xmx8192m\' bundle exec rails runner -epreproduction \'bi = Backup::Importer.new(2, \\\\\"/tmp/data/anderson/backup/backup_anderson\\\\\"); puts \\\\\"===== make =====\\\\\"; bi.make; puts \\\\\"===== update_count_all =====\\\\\"; bi.update_count_all; puts \\\\\"===== update_index =====\\\\\"; bi.update_index\'\"',
    'rm -rf /tmp/anderson.tar.bz2 /tmp/data',
  ],
    # taxman
  'taxerp-preprod-1' => %w{taxman taxman_gauges taxman_mobile taxman_reports taxman_tickets}.map {|db_name|
    ["tar -C /data/import -xjf /data/import/#{db_name}.tar.bz2",
      "rm /data/import/#{db_name}.tar.bz2",
      "mongorestore --host 172.16.2.1 --db #{db_name}_preproduction --drop /data/import/data/backup/#{db_name}/#{db_name}_production",
      "rm -rf /data/import/data/backup/#{db_name}",
    ]}.flatten.unshift('[ -e /data/import/data ] && rm -rf /data/import/data || true').push('rm -rf /data/import/data'),
  'si-factu-preprod-1' => [
    # killbill
    'bunzip2 -f /tmp/killbill.dump.bz2',
    'psql -U killbill_preproduction < <(sed -r -e \'s/OWNER TO killbill_production/OWNER TO killbill_preproduction/\' -e \'s/^CREATE TABLE ([^ ]*)/DROP TABLE IF EXISTS \\1;\\n\\nCREATE TABLE \\1/\' /tmp/killbill.dump)',
    'rm /tmp/killbill.dump',
  ],
  'si-proxy-preprod-1' => [
    # drive
    '[ -e /tmp/drive_production ] && rm -rf /tmp/drive_production || true',
    'tar -C /tmp -xjf /tmp/drive.tar.bz2',
    'mongorestore --host 172.16.1.1 --db drive_preproduction --drop /tmp/drive_production',
    'rm -rf /tmp/drive_production /tmp/drive.tar.bz2',
    # poussmouss
    '[ -e /tmp/pouss_mouss_production ] && rm -rf /tmp/pouss_mouss_production || true',
    'tar -C /tmp -xjf /tmp/poussmouss.tar.bz2',
    'mongorestore --host 172.16.1.1 --db pouss_mouss_preproduction --drop /tmp/pouss_mouss_production',
    'rm -rf /tmp/pouss_mouss_production  /tmp/poussmouss.tar.bz2',
  ],
}






puts <<EOF

#####################################################
# Stopping services                                 #
#####################################################

EOF

Services.each do |host,services|
  next if @hosts and not @hosts.include?(host)
  @threads << Thread.new do 
    services.each do |service,should_run|
      ssh(host, "monit stop #{service}")
    end
    services.each do |service,should_run|
      ssh(host, "while true; do stopped=\\\"\\\$(monit summary | grep \\\"'#{service}'.*[Nn]ot monitored\\\$\\\")\\\"; if [ -z \\\"\\\$stopped\\\" ]; then echo \\\"Waiting for #{service} to stop\\\"; sleep 30; else break; fi; done")
    end
  end
end

@threads.each {|thr| thr.join}
@threads.clear
sleep 2


puts <<EOF

#####################################################
# Flushing ActiveMQ queues...                       #
#####################################################

EOF

AMQueues.each do |host,queues|
  next if @hosts and not @hosts.include?(host)
  @threads << Thread.new do
    queues.each do |queue|
      ssh(host, "/opt/local/apache-activemq-5.5.1/bin/activemq-admin purge --pid \\\$(cat /var/run/activemq.pid) #{queue}")
    end
  end
end

@threads.each {|thr| thr.join}
@threads.clear
sleep 2



puts <<EOF

#####################################################
# Copying exports...                                #
#####################################################

EOF

ExportsFiles.each do |host,hash|
  next if @hosts and not @hosts.include?(host)
  @threads << Thread.new do
    source_files = hash[:files].map{|filename| "#{ExportsDirectory}/#{filename}"}.join(' ')
    ssh(ExportsHost, "scp -q -oUserKnownHostsFile=/dev/null -oStrictHostKeyChecking=no -oBatchMode=yes #{source_files} #{host}:#{hash[:destination_directory]}/", '-A')
  end
end

@threads.each {|thr| thr.join}
@threads.clear
sleep 2



puts <<EOF

#####################################################
# Importing...                                      #
#####################################################

EOF

ImportActions.each do |host,commands|
  next if @hosts and not @hosts.include?(host)
  @threads << Thread.new do
    commands.each do |command|
      ssh(host,command)
    end
  end
end

@threads.each {|thr| thr.join}
@threads.clear
sleep 2




# Restart, restart sélectif ou pas de restart ?

puts
puts
puts

while true
  print 'Restart all services? '
  str = gets
  break if str and str =~ /^[yo]$/i
  if str and str  =~ /^n$/i
    puts 'Commands to restart services: '
    puts Services.map {|host,services| services.map {|service| "ssh #{host} \"monit start #{service}\""} }.flatten
    puts 'Leaving now.'
    exit
  end
end



puts <<EOF

#####################################################
# Starting services...                              #
#####################################################

EOF

Services.each do |host,services|
  next if @hosts and not @hosts.include?(host)
  @threads << Thread.new do
    services.each do |service,should_run|
      ssh(host, "monit start #{service}") if should_run
    end
    services.each do |service,should_run|
      ssh(host, "while true; do running=\\\"\\\$(monit summary | grep \\\"'#{service}'.*[Rr]unning\\\$\\\")\\\"; if [ -z \\\"\\\$running\\\" ]; then echo \\\"Waiting for #{service} to start\\\"; sleep 30; else break; fi; done") if should_run
    end
  end
end

@threads.each {|thr| thr.join}
@threads.clear
sleep 2

threads_output_buffer_reader.terminate

puts "\nDone."
