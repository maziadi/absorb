#!/bin/bash


patch -p0 < lsb_wanrouter.patch
