package com.initsys.sigal.service.as.dao;

import com.initsys.sigal.service.as.VnodbEntry;

public interface VnodbDao {

    public abstract VnodbEntry queryDbByRef(String ref);

}
