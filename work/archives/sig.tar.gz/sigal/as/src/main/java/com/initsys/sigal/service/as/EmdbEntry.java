package com.initsys.sigal.service.as;

public class EmdbEntry {

	private String number;

	private String inseeCode;

	private String translatedNumber;

	private Integer dayOfWeek;

	private Integer index;
	
	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public Integer getDayOfWeek() {
		return dayOfWeek;
	}

	public void setDayOfWeek(Integer dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}

	public String getTranslatedNumber() {
		return translatedNumber;
	}

	public void setTranslatedNumber(String translation) {
		this.translatedNumber = translation;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getInseeCode() {
		return inseeCode;
	}

	public void setInseeCode(String inseeCode) {
		this.inseeCode = inseeCode;
	}
}
