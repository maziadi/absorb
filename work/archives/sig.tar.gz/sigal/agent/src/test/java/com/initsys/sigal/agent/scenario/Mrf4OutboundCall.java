package com.initsys.sigal.agent.scenario;

public class Mrf4OutboundCall extends AbstractScenario {
	public Mrf4OutboundCall() {
		// empty
	}

	public Mrf4OutboundCall(ClassLoader cl) {
		super(cl);
	}
}
