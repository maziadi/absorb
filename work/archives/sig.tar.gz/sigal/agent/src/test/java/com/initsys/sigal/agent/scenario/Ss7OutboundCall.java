package com.initsys.sigal.agent.scenario;

public class Ss7OutboundCall extends AbstractScenario {
	public Ss7OutboundCall() {
		super();
	}

	public Ss7OutboundCall(ClassLoader cl) {
		super(cl);
	}
}
