package com.initsys.sigal.agent.scenario;

public class SviRio extends AbstractScenario {
	public SviRio() {
		// empty
	}

	public SviRio(ClassLoader cl) {
		super(cl);
	}
}

