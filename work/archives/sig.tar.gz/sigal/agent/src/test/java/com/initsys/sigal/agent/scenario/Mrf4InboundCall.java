package com.initsys.sigal.agent.scenario;


public class Mrf4InboundCall extends AbstractScenario {
	public Mrf4InboundCall() {
		// empty
	}
	
	public Mrf4InboundCall(ClassLoader cl) {
		super(cl);
	}
}
