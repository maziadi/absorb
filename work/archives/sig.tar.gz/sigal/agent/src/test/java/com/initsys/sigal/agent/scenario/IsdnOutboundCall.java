package com.initsys.sigal.agent.scenario;

public class IsdnOutboundCall extends AbstractScenario {
	public IsdnOutboundCall() {
		// empty
	}

	public IsdnOutboundCall(ClassLoader cl) {
		super(cl);
	}
}
